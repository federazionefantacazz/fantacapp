/**
 * Test standalone delle probabili formazioni: NON scrive su Firebase.
 * Uso (dalla cartella functions/):
 *   node test-probabili.js            -> riepilogo + prime partite
 *   node test-probabili.js 4312       -> dettaglio di un giocatore (id listone)
 */
const {fetchProbabili} = require("./probabili");

(async () => {
  const data = await fetchProbabili();
  const ids = Object.keys(data.players);
  console.log(`Giornata ${data.giornata}: ${Object.keys(data.fixtures).length / 2} partite, ${ids.length} giocatori\n`);

  const id = process.argv[2];
  if (id) {
    console.log(id, data.players[id] || "non presente");
    const p = data.players[id];
    if (p) console.log("Avversario:", data.fixtures[p.team]);
    return;
  }
  for (const [slug, f] of Object.entries(data.fixtures)) {
    if (f.home) console.log(`${f.name} - ${f.oppName}  (${f.date || "data n.d."})`);
  }
  const conStato = ids.filter((i) => data.players[i].st).slice(0, 8);
  console.log("\nEsempi con stato:");
  conStato.forEach((i) => console.log(" ", i, data.players[i]));
})().catch((e) => {
  console.error("ERRORE:", e.message);
  process.exit(1);
});
