/**
 * fantacapp - Live Votes Cloud Function
 * ---------------------------------------------------------------
 * Porting in Node.js del meccanismo usato da "fantacalcio-voti-live":
 *   1) POST a fantacalcio.it/api/v1/SignedUri per ottenere un link firmato
 *      al file binario dei voti della giornata (.dat)
 *   2) download del file e decodifica come messaggio Protobuf ("LiveMessage",
 *      schema in proto.json) usando protobufjs
 *   3) estrazione dei giocatori (id, voto, eventi) per le squadre che
 *      interessano e scrittura diretta su Realtime Database, nello stesso
 *      path/formato che liveMatch.js già consuma:
 *          votes/gw{giornataReale}/{playerId} = { voto, live: true, ... }
 *
 * Non serve nessun subprocess Node esterno (a differenza dello scraper
 * Python originale che invocava `node decode_livemessage_pb.js`): qui siamo
 * già in ambiente Node, quindi protobufjs viene usato direttamente in-process.
 */

const {onSchedule} = require("firebase-functions/v2/scheduler");
const {onCall, HttpsError} = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");
const admin = require("firebase-admin");
const protobuf = require("protobufjs");

const protoJson = require("./proto.json");
const SQUADRE = require("./squadre");

admin.initializeApp({
  databaseURL: "https://fantcapp-default-rtdb.europe-west1.firebasedatabase.app",
});
const rtdb = admin.database();

const root = protobuf.Root.fromJSON(protoJson);
const LiveMessage = root.lookupType("LiveMessage");

const REGION = "europe-west1"; // stessa region del tuo databaseURL (europe-west1)

const COMMON_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/117.0",
  "Accept": "*/*",
  "Accept-Language": "en-GB,en;q=0.5",
};

/**
 * Passo 1: chiede a fantacalcio.it un URI firmato temporaneo che punta al
 * file .dat della giornata richiesta.
 */
async function getSignedUri(giornata, seasonId) {
  const uri = `https://api.fantacalcio.it/v1/st/${seasonId}/matches/live/${giornata}.dat`;

  const resp = await fetch("https://www.fantacalcio.it/api/v1/SignedUri", {
    method: "POST",
    headers: {
      ...COMMON_HEADERS,
      "Content-Type": "application/json",
      "Origin": "https://www.fantacalcio.it",
    },
    body: JSON.stringify({resourcesUri: [uri]}),
  });

  if (!resp.ok) {
    throw new Error(`SignedUri HTTP ${resp.status}`);
  }

  const data = await resp.json();
  const entry = data[uri];
  if (!entry || !entry.resources || !entry.resources[0]) {
    throw new Error("Risposta SignedUri inattesa: " + JSON.stringify(data).slice(0, 300));
  }
  return entry.resources[0].signedUri;
}

/**
 * Passo 2: scarica il file .dat e lo decodifica come messaggio protobuf.
 */
async function fetchLiveMessage(signedUri) {
  const resp = await fetch(signedUri, {
    headers: {
      ...COMMON_HEADERS,
      "Referer": "https://www.fantacalcio.it/",
      "Origin": "https://www.fantacalcio.it",
    },
  });

  if (!resp.ok) {
    throw new Error(`Download .dat HTTP ${resp.status}`);
  }

  const arrayBuffer = await resp.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  return LiveMessage.decode(buffer);
}

/**
 * Passo 3: dal messaggio decodificato estrae l'array giocatori della
 * squadra richiesta (sia se gioca in casa che in trasferta).
 */
function extractPlayersForTeam(liveMessage, teamId) {
  const matches = liveMessage.protoData || [];
  for (const match of matches) {
    if (match.teamIdHome === teamId) return match.playersHome || [];
    if (match.teamIdAway === teamId) return match.playersAway || [];
  }
  return [];
}

/**
 * Legge lo stato della sessione live da settings/liveSession e, se attiva,
 * scarica/decodifica/scrive i voti per tutte le squadre monitorate.
 *
 * Formato atteso in settings/liveSession:
 * {
 *   active: true,
 *   giornataReale: 5,              // numero di giornata di Serie A
 *   squadre: ["Milan", "Napoli"],  // nomi come in squadre.js
 *   seasonId: 21,                  // da verificare ad ogni nuova stagione
 *   until: "23:30"                 // HH:MM ora italiana, oltre la quale si ferma da sola
 * }
 */
async function runLiveTick() {
  const sessionSnap = await rtdb.ref("settings/liveSession").get();
  const session = sessionSnap.val();

  if (!session || !session.active) {
    logger.debug("Nessuna sessione live attiva, esco.");
    return;
  }

  if (session.until) {
    const nowRome = new Intl.DateTimeFormat("it-IT", {
      timeZone: "Europe/Rome",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date());

    if (nowRome >= session.until) {
      await rtdb.ref("settings/liveSession/active").set(false);
      logger.info(`Orario limite (${session.until}) raggiunto, sessione live fermata.`);
      return;
    }
  }

  const giornata = session.giornataReale;
  const seasonId = session.seasonId || 21;
  const squadre = session.squadre || [];

  if (!giornata || squadre.length === 0) {
    logger.warn("giornataReale o squadre mancanti in settings/liveSession.");
    return;
  }

  const updates = {};
  const now = admin.database.ServerValue.TIMESTAMP;

  for (const nomeSquadra of squadre) {
    const teamId = SQUADRE[nomeSquadra];
    if (teamId === undefined) {
      logger.warn(`Squadra sconosciuta in squadre.js: "${nomeSquadra}"`);
      continue;
    }

    try {
      const signedUri = await getSignedUri(giornata, seasonId);
      const liveMessage = await fetchLiveMessage(signedUri);
      const players = extractPlayersForTeam(liveMessage, teamId);

      let scritti = 0;
      for (const p of players) {
        // Salta i giocatori senza ancora un voto reale (in panchina/non entrati):
        // evita di sovrascrivere con 0 eventuali voti già inseriti a mano.
        const hasVote = p.vote && Number(p.vote) > 0;
        const hasEvents = p.events && p.events.length > 0;
        if (!hasVote && !hasEvents) continue;

        updates[`votes/gw${giornata}/${p.id}`] = {
          voto: Number(p.vote) || 0,
          live: true,
          updatedAt: now,
        };
        scritti++;
      }

      logger.info(`${nomeSquadra}: ${scritti}/${players.length} giocatori aggiornati.`);
    } catch (err) {
      logger.error(`Errore recupero voti per ${nomeSquadra}: ${err.message}`);
    }
  }

  if (Object.keys(updates).length > 0) {
    await rtdb.ref().update(updates);
    logger.info(`Scritti ${Object.keys(updates).length} voti su votes/gw${giornata}.`);
  }
}

/**
 * Trigger schedulato: gira ogni minuto (minimo consentito da Cloud
 * Scheduler) ma esce subito se non c'è una sessione live attiva, quindi
 * fuori dagli orari delle partite non genera traffico né costi.
 */
exports.liveVotesTick = onSchedule(
  {
    schedule: "every 1 minutes",
    timeZone: "Europe/Rome",
    region: REGION,
  },
  async () => {
    await runLiveTick();
  }
);

/**
 * Funzione callable da usare dal pannello admin per avviare/fermare il
 * tracking live (equivalente ai parametri --giornata/--until dello
 * scraper.py originale, ma pilotabile da UI invece che da CLI).
 *
 * Esempio di chiamata dal client:
 *   const toggle = httpsCallable(functions, "toggleLiveTracking");
 *   await toggle({ active: true, giornataReale: 5, squadre: ["Milan","Napoli"], until: "23:30" });
 */
exports.toggleLiveTracking = onCall({region: REGION}, async (request) => {
  const {active, giornataReale, squadre, until, seasonId} = request.data || {};

  if (active) {
    if (!giornataReale || !Array.isArray(squadre) || squadre.length === 0) {
      throw new HttpsError(
        "invalid-argument",
        "giornataReale e squadre (array) sono obbligatori per avviare il tracking."
      );
    }
    await rtdb.ref("settings/liveSession").set({
      active: true,
      giornataReale,
      squadre,
      until: until || "23:59",
      seasonId: seasonId || 21,
      startedAt: admin.database.ServerValue.TIMESTAMP,
    });
  } else {
    await rtdb.ref("settings/liveSession/active").set(false);
  }

  return {ok: true};
});

/**
 * Funzione callable per forzare subito un aggiornamento (utile per test
 * manuali dal pannello admin, senza aspettare il prossimo tick schedulato).
 */
exports.runLiveVotesNow = onCall({region: REGION}, async () => {
  await runLiveTick();
  return {ok: true};
});
