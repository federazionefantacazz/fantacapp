/**
 * Mappa "Nome Squadra" -> id numerico interno usato dall'API di fantacalcio.it.
 * Porting diretto di squadre.py del progetto fantacalcio-voti-live.
 *
 * ATTENZIONE: alcuni id (soprattutto quelli delle neopromosse) possono
 * cambiare da una stagione all'altra. Se una squadra risulta "sconosciuta"
 * nei log della Cloud Function, vuol dire che l'id non è più valido e va
 * riverificato ispezionando il traffico di rete di fantacalcio.it durante
 * una partita di quella squadra.
 */
module.exports = {
  "Atalanta": 1,
  "Bologna": 2,
  "Cagliari": 21,
  "Empoli": 5,
  "Fiorentina": 6,
  "Frosinone": 7,
  "Genoa": 8,
  "Inter": 9,
  "Juventus": 10,
  "Lazio": 11,
  "Lecce": 119,
  "Milan": 12,
  "Monza": 143,
  "Napoli": 13,
  "Roma": 15,
  "Salernitana": 137,
  "Sampdoria": 16,
  "Sassuolo": 17,
  "Spezia": 129,
  "Torino": 18,
  "Udinese": 19,
  "Venezia": 138,
  "Verona": 20,
  "Parma": 107,
  "Como": 153,
  "Pisa": 157,
  "Cremonese": 144,
};
