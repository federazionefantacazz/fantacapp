/**
 * fantacapp - Probabili formazioni da fantacalcio.it
 * ---------------------------------------------------------------
 * Scarica https://www.fantacalcio.it/probabili-formazioni-serie-a e ne
 * estrae, per ogni calciatore:
 *   - percentuale di impiego (es. 90%)
 *   - se è titolare o in panchina nella probabile formazione
 *   - stato: squalificato / diffidato / infortunato / in dubbio (+ nota)
 * e, per ogni squadra di Serie A, l'avversario della giornata.
 *
 * Il parser NON dipende dalle classi CSS del sito (che cambiano spesso):
 * legge il flusso di link e testi della pagina, sfruttando il fatto che
 *   - ogni calciatore è un link /serie-a/squadre/{squadra}/{slug}/{id}
 *     dove {id} è lo stesso id usato nel listone (quotazioni fantacalcio)
 *   - ogni partita ha un link /serie-a/calendario/{gw}/{stagione}/{casa}-{trasferta}/{id}
 *   - le sezioni sono introdotte da titoli "Panchina", "Squalificati",
 *     "Diffidati", "Infortunati", "In dubbio", "Ballottaggi".
 *
 * Risultato scritto su Realtime Database in `probabili/`:
 *   probabili/meta     = { giornata, updatedAt, matches, players }
 *   probabili/fixtures = { genoa: { opp: "fiorentina", oppName: "Fiorentina", home: true, date: "sabato 10 ottobre, 15:00" }, ... }
 *   probabili/players  = { "7332": { pct: 90, xi: "tit"|"pan", st: "inf"|"squal"|"diff"|"dubbio", note: "...", team: "genoa" }, ... }
 */

const URL_PROBABILI = "https://www.fantacalcio.it/probabili-formazioni-serie-a";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/117.0",
  "Accept": "text/html,application/xhtml+xml",
  "Accept-Language": "it-IT,it;q=0.9",
};

const RE_PLAYER = /\/serie-a\/squadre\/([^/"?#]+)\/([^/"?#]+)\/(\d+)\/?$/;
const RE_TEAM = /\/serie-a\/squadre\/([^/"?#]+)\/?$/;
const RE_MATCH = /\/serie-a\/calendario\/(\d+)\/([^/]+)\/([^/"?#]+)\/(\d+)\/?$/;
const RE_PCT = /^(\d{1,3})\s*%$/;
const RE_DATE = /^(luned[iì]|marted[iì]|mercoled[iì]|gioved[iì]|venerd[iì]|sabato|domenica)\s+\d/i;

const MARKERS = {
  "panchina": "pan",
  "squalificati": "squal",
  "diffidati": "diff",
  "infortunati": "inf",
  "in dubbio": "dubbio",
  "ballottaggi": "ballottaggi",
};
// Priorità quando un giocatore compare in più sezioni (vince la più grave)
const STATUS_RANK = {squal: 4, inf: 3, dubbio: 2, diff: 1};

function decodeEntities(s) {
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&nbsp;/g, " ")
    .replace(/&quot;/g, "\"")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

/** Spezza l'HTML in una sequenza di token {type:'a', href} | {type:'/a'} | {type:'text', text} */
function tokenize(html) {
  // via script/style/commenti/svg: non contengono dati utili e possono contenere '%' o nomi
  const clean = html
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(script|style|noscript|svg)\b[\s\S]*?<\/\1>/gi, " ");

  const tokens = [];
  const re = /<[^>]+>|[^<]+/g;
  let m;
  while ((m = re.exec(clean))) {
    const chunk = m[0];
    if (chunk[0] === "<") {
      const a = /^<a\b[^>]*\bhref\s*=\s*["']([^"']*)["']/i.exec(chunk);
      if (a) tokens.push({type: "a", href: decodeEntities(a[1])});
      else if (/^<\/a\s*>/i.test(chunk)) tokens.push({type: "/a"});
    } else {
      const text = decodeEntities(chunk).replace(/\s+/g, " ").trim();
      if (text) tokens.push({type: "text", text});
    }
  }
  return tokens;
}

function hrefPath(href) {
  try {
    return new URL(href, "https://www.fantacalcio.it").pathname;
  } catch (e) {
    return href;
  }
}

function markerOf(text) {
  const t = text.replace(/^[-–—\s|]+/, "").replace(/[\s:]+$/, "").toLowerCase();
  return MARKERS[t] || null;
}

function parseProbabili(html) {
  const tokens = tokenize(html);

  const teamNames = {}; // slug -> nome esteso
  const matches = {}; // matchId -> { gw, home, away, date }
  const players = {}; // id -> dati

  let curMatch = null;
  let section = "pre"; // pre | tit | pan | squal | diff | inf | dubbio | ballottaggi
  let panTeam = null;
  let lastPlayer = null; // id dell'ultimo link calciatore visto
  let lastPlayerHasPct = false;
  let inAnchor = null; // {kind, ...}

  const ensure = (id, team) => {
    if (!players[id]) players[id] = {team};
    return players[id];
  };

  for (const tk of tokens) {
    if (tk.type === "a") {
      const path = hrefPath(tk.href);
      let m;
      if ((m = RE_MATCH.exec(path))) {
        const [, gw, , slugPair, matchId] = m;
        if (!matches[matchId]) matches[matchId] = {gw: Number(gw), pair: slugPair, date: null};
        curMatch = matchId;
        section = "pre";
        panTeam = null;
        lastPlayer = null;
        inAnchor = {kind: "match"};
      } else if ((m = RE_PLAYER.exec(path))) {
        const [, team, , id] = m;
        lastPlayer = id;
        lastPlayerHasPct = false;
        ensure(id, team);
        inAnchor = {kind: "player", id};

        // Dopo "Panchina": se cambia squadra siamo passati ai titolari dell'altra squadra
        if (section === "pan") {
          if (panTeam === null) panTeam = team;
          else if (panTeam !== team) {
            section = "tit";
            panTeam = null;
          }
        }
        // Status (sezioni dettaglio)
        if (["squal", "diff", "inf", "dubbio"].includes(section)) {
          const p = players[id];
          if (!p.st || STATUS_RANK[section] > STATUS_RANK[p.st]) {
            p.st = section;
            p.note = "";
          }
          p._noteTarget = p.st === section;
        }
      } else if ((m = RE_TEAM.exec(path))) {
        inAnchor = {kind: "team", slug: m[1]};
      } else {
        inAnchor = {kind: "other"};
      }
      continue;
    }

    if (tk.type === "/a") {
      inAnchor = null;
      continue;
    }

    // ---- testo ----
    const text = tk.text;

    if (inAnchor && inAnchor.kind === "team") {
      const prev = teamNames[inAnchor.slug] || "";
      if (text.length > prev.length) teamNames[inAnchor.slug] = text;
      continue;
    }
    if (inAnchor && inAnchor.kind === "player") {
      const p = players[inAnchor.id];
      if (!p.name || text.length > p.name.length) p.name = text;
      continue;
    }

    const mk = markerOf(text);
    if (mk && curMatch) {
      section = mk;
      if (mk === "pan") panTeam = null;
      lastPlayer = null;
      continue;
    }
    if (!curMatch) continue;

    if (!matches[curMatch].date && text.length < 40 && RE_DATE.test(text)) {
      matches[curMatch].date = text;
      continue;
    }

    const pm = RE_PCT.exec(text);
    if (pm && lastPlayer && !lastPlayerHasPct) {
      lastPlayerHasPct = true;
      const p = players[lastPlayer];
      if (p.pct === undefined) {
        p.pct = Math.min(100, Number(pm[1]));
        // Il primo % di un giocatore arriva dalla probabile formazione
        if (section === "pre" || section === "tit") {
          section = "tit";
          p.xi = "tit";
        } else if (section === "pan") {
          p.xi = "pan";
        }
      }
      continue;
    }

    // Nota testuale (infortunio, squalifica...) subito dopo il link del giocatore
    if (lastPlayer && ["squal", "diff", "inf", "dubbio"].includes(section)) {
      const p = players[lastPlayer];
      if (p._noteTarget && !/^nessun calciatore$/i.test(text) && (p.note || "").length < 200) {
        p.note = p.note ? `${p.note} ${text}` : text;
      }
    }
  }

  // ---- fixtures: risolvo "casa-trasferta" con gli slug squadra noti ----
  const slugs = Object.keys(teamNames).sort((a, b) => b.length - a.length);
  const fixtures = {};
  let giornata = null;
  for (const id of Object.keys(matches)) {
    const mt = matches[id];
    giornata = giornata === null ? mt.gw : Math.max(giornata, mt.gw);
    let home = null;
    let away = null;
    for (const s of slugs) {
      if (mt.pair.startsWith(s + "-") && slugs.includes(mt.pair.slice(s.length + 1))) {
        home = s;
        away = mt.pair.slice(s.length + 1);
        break;
      }
    }
    if (!home) {
      // fallback: primo trattino
      const i = mt.pair.indexOf("-");
      home = mt.pair.slice(0, i);
      away = mt.pair.slice(i + 1);
    }
    const nm = (s) => teamNames[s] || s.charAt(0).toUpperCase() + s.slice(1);
    fixtures[home] = {opp: away, oppName: nm(away), name: nm(home), home: true, date: mt.date || null};
    fixtures[away] = {opp: home, oppName: nm(home), name: nm(away), home: false, date: mt.date || null};
  }

  // pulizia campi interni / vuoti
  const out = {};
  for (const [id, p] of Object.entries(players)) {
    delete p._noteTarget;
    if (p.pct === undefined && !p.st) continue; // compare solo nelle "figurine" in alto
    const clean = {};
    for (const [k, v] of Object.entries(p)) if (v !== undefined && v !== null && v !== "") clean[k] = v;
    out[id] = clean;
  }

  return {giornata, fixtures, players: out};
}

async function fetchProbabili() {
  const resp = await fetch(URL_PROBABILI, {headers: HEADERS});
  if (!resp.ok) throw new Error(`probabili-formazioni HTTP ${resp.status}`);
  const html = await resp.text();
  return parseProbabili(html);
}

/** Scarica, interpreta e scrive su RTDB (path `probabili`). */
async function aggiornaProbabili(rtdb, admin, logger) {
  const data = await fetchProbabili();
  const nMatch = Object.keys(data.fixtures).length / 2;
  const nPlayers = Object.keys(data.players).length;

  // Pagina vuota o cambiata radicalmente: non sovrascrivo i dati buoni
  if (nMatch < 1 || nPlayers < 50) {
    throw new Error(`Parsing sospetto (partite: ${nMatch}, giocatori: ${nPlayers}): dati non salvati.`);
  }

  await rtdb.ref("probabili").set({
    meta: {
      giornata: data.giornata,
      updatedAt: admin.database.ServerValue.TIMESTAMP,
      matches: nMatch,
      players: nPlayers,
    },
    fixtures: data.fixtures,
    players: data.players,
  });
  if (logger) logger.info(`Probabili G${data.giornata}: ${nMatch} partite, ${nPlayers} giocatori.`);
  return {giornata: data.giornata, matches: nMatch, players: nPlayers};
}

module.exports = {parseProbabili, fetchProbabili, aggiornaProbabili};
