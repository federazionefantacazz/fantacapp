/**
 * Test standalone: NON tocca Firebase, serve solo per verificare che il
 * meccanismo SignedUri -> download .dat -> decodifica protobuf funzioni,
 * anche se in questo momento non ci sono partite live in corso.
 *
 * Uso (da dentro la cartella functions/, dopo npm install):
 *   node test-live.js <giornata> [nomeSquadra]
 *
 * Esempi:
 *   node test-live.js 5                 -> stampa l'intero messaggio decodificato
 *   node test-live.js 5 Milan           -> stampa solo i giocatori del Milan
 *
 * Nota: se la giornata indicata non è mai partita/non esiste ancora sui
 * server di fantacalcio.it, la richiesta SignedUri o il download del .dat
 * potrebbero fallire con un errore HTTP: è normale, significa solo che per
 * quella giornata non c'è ancora nessun file pubblicato, non un bug del
 * codice.
 */

const protobuf = require("protobufjs");
const protoJson = require("./proto.json");
const SQUADRE = require("./squadre");

const root = protobuf.Root.fromJSON(protoJson);
const LiveMessage = root.lookupType("LiveMessage");

const COMMON_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/117.0",
  "Accept": "*/*",
  "Accept-Language": "en-GB,en;q=0.5",
};

async function getSignedUri(giornata, seasonId) {
  const uri = `https://api.fantacalcio.it/v1/st/${seasonId}/matches/live/${giornata}.dat`;

  console.log(`\n[1/3] Richiedo SignedUri per: ${uri}`);
  const resp = await fetch("https://www.fantacalcio.it/api/v1/SignedUri", {
    method: "POST",
    headers: {
      ...COMMON_HEADERS,
      "Content-Type": "application/json",
      "Origin": "https://www.fantacalcio.it",
    },
    body: JSON.stringify({resourcesUri: [uri]}),
  });

  console.log(`      Risposta HTTP: ${resp.status}`);
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`SignedUri HTTP ${resp.status}: ${text.slice(0, 300)}`);
  }

  const data = await resp.json();
  const entry = data[uri];
  if (!entry || !entry.resources || !entry.resources[0]) {
    throw new Error("Risposta SignedUri inattesa: " + JSON.stringify(data).slice(0, 300));
  }
  console.log("      SignedUri ottenuto correttamente.");
  return entry.resources[0].signedUri;
}

async function fetchLiveMessage(signedUri) {
  console.log("\n[2/3] Scarico il file .dat...");
  const resp = await fetch(signedUri, {
    headers: {
      ...COMMON_HEADERS,
      "Referer": "https://www.fantacalcio.it/",
      "Origin": "https://www.fantacalcio.it",
    },
  });

  console.log(`      Risposta HTTP: ${resp.status}`);
  if (!resp.ok) {
    throw new Error(`Download .dat HTTP ${resp.status}`);
  }

  const arrayBuffer = await resp.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  console.log(`      File scaricato: ${buffer.length} byte.`);

  console.log("\n[3/3] Decodifico il protobuf...");
  const decoded = LiveMessage.decode(buffer);
  console.log("      Decodifica riuscita.");
  return decoded;
}

async function main() {
  const [, , giornataArg, squadraArg] = process.argv;
  const giornata = Number(giornataArg);
  const seasonId = 21; // se fallisce, è il primo valore da sospettare/verificare

  if (!giornata) {
    console.error("Uso: node test-live.js <giornata> [nomeSquadra]");
    process.exit(1);
  }

  try {
    const signedUri = await getSignedUri(giornata, seasonId);
    const liveMessage = await fetchLiveMessage(signedUri);

    const matches = liveMessage.protoData || [];
    console.log(`\n=== Trovate ${matches.length} partite per la giornata ${giornata} ===`);
    for (const m of matches) {
      console.log(`  ${m.teamHome} (id ${m.teamIdHome}) vs ${m.teamAway} (id ${m.teamIdAway}) - stato: ${m.status}`);
    }

    if (squadraArg) {
      const teamId = SQUADRE[squadraArg];
      if (teamId === undefined) {
        console.error(`\nSquadra "${squadraArg}" non trovata in squadre.js`);
        process.exit(1);
      }
      const match = matches.find((m) => m.teamIdHome === teamId || m.teamIdAway === teamId);
      if (!match) {
        console.log(`\nNessuna partita trovata per "${squadraArg}" (id ${teamId}) in questa giornata.`);
        return;
      }
      const players = match.teamIdHome === teamId ? match.playersHome : match.playersAway;
      console.log(`\n=== Giocatori ${squadraArg} (${players.length}) ===`);
      for (const p of players) {
        console.log(`  ${p.name.padEnd(20)} voto: ${p.vote}  eventi: [${p.events.join(",")}]`);
      }
    } else {
      console.log("\n(Suggerimento: passa anche il nome squadra come secondo argomento per vedere i singoli giocatori, es: node test-live.js " + giornata + " Milan)");
    }
  } catch (err) {
    console.error("\n❌ Errore:", err.message);
    process.exit(1);
  }
}

main();
