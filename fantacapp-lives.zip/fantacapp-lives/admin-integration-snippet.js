/**
 * Snippet di integrazione per il pannello admin (es. dentro js/admin/votes.js
 * o un nuovo js/admin/liveTracking.js).
 *
 * Aggiunge 3 azioni pilotabili da UI:
 *  - avviare il tracking live per una giornata reale + elenco squadre
 *  - fermarlo
 *  - forzare un aggiornamento immediato (utile per test)
 *
 * Richiede di importare l'SDK Functions accanto a quello già usato per
 * Database/Auth in firebase-config.js.
 */

import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-functions.js";
import { fapp } from "./firebase-config.js"; // assicurati che firebase-config.js esporti anche `fapp`

const functions = getFunctions(fapp, "europe-west1");

export const LiveTrackingAdmin = {
  async start({ giornataReale, squadre, until }) {
    const toggle = httpsCallable(functions, "toggleLiveTracking");
    const res = await toggle({
      active: true,
      giornataReale: Number(giornataReale),
      squadre, // es: ["Milan", "Napoli", "Inter"]
      until: until || "23:30",
    });
    return res.data;
  },

  async stop() {
    const toggle = httpsCallable(functions, "toggleLiveTracking");
    const res = await toggle({ active: false });
    return res.data;
  },

  async runNow() {
    const run = httpsCallable(functions, "runLiveVotesNow");
    const res = await run();
    return res.data;
  },
};

/* Esempio di markup + wiring minimale da aggiungere in una sezione admin:

<input id="liveGiornata" type="number" placeholder="Giornata reale (es. 5)">
<input id="liveSquadre" type="text" placeholder="Milan, Napoli, Inter">
<input id="liveUntil" type="time" value="23:30">
<button id="btnStartLive">▶️ Avvia Live</button>
<button id="btnStopLive">⏹️ Ferma Live</button>
<button id="btnRunNowLive">⚡ Aggiorna ora</button>

document.getElementById('btnStartLive').addEventListener('click', async () => {
  const giornataReale = document.getElementById('liveGiornata').value;
  const squadre = document.getElementById('liveSquadre').value.split(',').map(s => s.trim()).filter(Boolean);
  const until = document.getElementById('liveUntil').value;
  await LiveTrackingAdmin.start({ giornataReale, squadre, until });
  window.toast("Live tracking avviato!", "ok");
});

document.getElementById('btnStopLive').addEventListener('click', async () => {
  await LiveTrackingAdmin.stop();
  window.toast("Live tracking fermato.", "info");
});

document.getElementById('btnRunNowLive').addEventListener('click', async () => {
  await LiveTrackingAdmin.runNow();
  window.toast("Aggiornamento forzato eseguito.", "ok");
});

*/
