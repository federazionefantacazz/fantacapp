# Live votes per fantacapp — Firebase Cloud Function

Questa cartella porta in `fantacapp` lo stesso meccanismo di
`fantacalcio-voti-live` (SignedUri → file protobuf → decodifica), ma come
Cloud Function Node.js che scrive direttamente su Realtime Database, nel
path già letto da `liveMatch.js`:

```
votes/gw{giornataReale}/{playerId} = { voto, live: true, updatedAt }
```

Nessuna modifica al frontend è necessaria: `liveMatch.js` legge già da lì.
Nota: nel codice attuale il campo `fVoto` non viene mai scritto da nessuna
parte dell'app (solo letto), quindi per ora la function scrive solo `voto` —
è già sufficiente perché `liveMatch.js` usa `voto` come fallback quando
`fVoto` non è presente.

## Cosa manca ancora (limite noto)

Il campo `events` del protobuf (array di codici numerici per gol, assist,
ammonizioni, ecc.) non ha una mappatura documentata nel progetto originale:
lo scraper Python lo salvava così com'è, senza tradurlo. Per calcolare
bonus/malus automaticamente andrebbe dedotta la mappa codice→evento
osservando qualche partita live e confrontando con l'app ufficiale — se vuoi
posso aiutarti a farlo in un secondo momento, quando avrai dei dati live
reali da ispezionare.

## Struttura

```
functions/
  index.js       -> logica scraping + scrittura RTDB + trigger schedulato/callable
  proto.json     -> schema Protobuf (identico all'originale)
  squadre.js     -> mappa nome squadra -> id numerico fantacalcio.it
  package.json   -> dipendenze (firebase-admin, firebase-functions, protobufjs)
admin-integration-snippet.js -> esempio di UI/wiring per il pannello admin
```

## Deploy

Se il progetto Firebase non ha ancora una cartella `functions/`:

```bash
firebase init functions
# scegli JavaScript, Node 20, NO a ESLint se non lo usi già
```

Poi sostituisci/copia dentro la tua cartella `functions/` i file di questa
cartella (`index.js`, `proto.json`, `squadre.js`, `package.json` — fai
merge delle dependencies se il tuo `package.json` ha già altro).

```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

**Importante:** le Cloud Functions v2 richiedono il piano **Blaze**
(pay-as-you-go) anche per l'uso gratuito entro le soglie incluse — è un
prerequisito di Firebase, non di questo codice. Con un trigger schedulato
che gira 1 volta al minuto solo mentre c'è una sessione live attiva, il
costo realistico è pochi centesimi al mese.

## Come si avvia il tracking live

La function non gira mai "a vuoto": controlla `settings/liveSession` su
RTDB e se `active` non è `true` esce subito senza fare nessuna richiesta
esterna. Per avviarla, dal pannello admin (vedi
`admin-integration-snippet.js`):

```js
await LiveTrackingAdmin.start({
  giornataReale: 5,                 // numero di giornata Serie A (non la GW di lega)
  squadre: ["Milan", "Napoli"],     // squadre reali coinvolte nelle formazioni della tua lega
  until: "23:30"                    // si ferma da sola a quest'ora (fuso Europe/Rome)
});
```

Da questo momento, ogni minuto la function scarica e aggiorna i voti live
per quelle squadre, finché non chiami `LiveTrackingAdmin.stop()` o non
scatta l'orario `until`.

Per integrarlo, aggiungi anche in `js/firebase-config.js`:

```js
export const fapp = initializeApp(firebaseConfig); // invece di `const fapp = ...`
```

così `admin-integration-snippet.js` può importarlo.

## Note su `seasonId` e sugli id squadra

- `seasonId` (default `19` nel codice) è un numero interno di
  fantacalcio.it che identifica la stagione corrente e **può cambiare ogni
  anno**. Se le richieste iniziano a fallire a inizio stagione, è il primo
  sospettato: va riverificato ispezionando il traffico di rete di
  fantacalcio.it (pannello Network del browser) durante una richiesta ai
  voti live.
- `squadre.js` contiene gli id delle squadre della stagione del progetto
  originale: le neopromosse cambiano id ogni anno, quelle "storiche"
  restano stabili da diverse stagioni ma vale comunque la pena una verifica
  a inizio campionato.

## Perché non farlo girare nel browser

La richiesta POST a `fantacalcio.it/api/v1/SignedUri` non ha (con ogni
probabilità) CORS aperto per origini esterne alla tua app, quindi il
browser dell'utente non potrebbe comunque completarla. Per questo la stessa
identica logica va eseguita server-side — qui la Cloud Function fa da
sostituto diretto di `scraper.py` + `decode_livemessage_pb.js`.
